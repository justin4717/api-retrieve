<?php
require __DIR__ . '/vendor/autoload.php';
use ApiRes\ApiRes;

$api = new ApiRes();

$api->apiUrl = 'https://reqres.in/api/users/2';
var_dump($api->getFromApi());

$api->apiUrl = 'https://reqres.in/api/users?page=2';
var_dump($api->getFromApi());

?>